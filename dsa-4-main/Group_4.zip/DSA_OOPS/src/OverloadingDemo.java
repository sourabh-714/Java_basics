class OnlineShop {
	public void search(double price) {
		
	}
	public void search(String brand) {
		
	}
	public void search(String category, String brand) {
		
	}
	
}


public class OverloadingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
