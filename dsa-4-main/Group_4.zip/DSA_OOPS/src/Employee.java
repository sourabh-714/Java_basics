
public class Employee {
	private int empId;
	private String name;
	private double salary;
	
	private String email;
	private String dept;
	private String designation;
	private String company;
	
	public Employee() {
		this.company = "Brain Mentors";
	}
	
	public Employee(int id, String name, double salary) {
		this(); // constructor chaining
		this.empId = id;
		this.name = name;
		this.salary = salary;
	}
	
	
	// 1. Generate getter setter
	// 2. create functions to calculate hra, da, ta, ma
	// 3. create a function to calculate net salary
	
	public double getHra() {
		return salary * 0.25;
	}
	
	public double getTA() {
		return salary * 0.15;
	}
	
	public double getDA() {
		return salary * 0.10;
	}
	
	public double getPF() {
		return salary * 0.10;
	}
	
	public double getTDS() {
		return salary * 0.15;
	}
	
	public double getNetSalary() {
		return salary + getHra() + getDA() + getTA() - getPF() - getTDS();
	}
	
	public String printReport() {
		CommonUtils obj = new CommonUtils();
		obj.getProperName(name);
		String sal = obj.salaryFormat(getNetSalary());
		// return name, basic salary, net salary
		
		return "ID : " + empId + "\nName : " + name + "\nSalary : "+sal;
	}
}
