
public class StringMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "Ravi";
		System.out.println(name.length());
		System.out.println(name.charAt(0));
		System.out.println(name.substring(1, 3));
		String name2 = "    Ravi    ";
		System.out.println(name2);
		System.out.println(name2.trim());
		System.out.println(name2.replace("v", "b"));
		System.out.println(name.indexOf('a'));
		System.out.println(name.startsWith("A"));
		System.out.println(name.endsWith("?"));
		System.out.println(name.contains("x"));
		System.out.println("Ravi".equals(name));
		System.out.println("Ravi".equalsIgnoreCase(name));
		
		String arr[] = "Hello how are you ?".split(" ");
		System.out.println(arr.length);
		
	}

}
