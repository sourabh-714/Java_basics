
public class CommonUtils {
	public String getProperName(String name) {
		String fullName = "";
		String names[] = name.split(" ");
		// code to convert name into proper name
		return fullName;
	}
	
	public String salaryFormat(double salary) {
		String formatSalary = "";
//		convert salary to indian format
		return formatSalary;
	}
}
