
public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee ram = new Employee(101,"Ram", 35000);
		String report = ram.printReport();
		System.out.println(report);
	}

}
