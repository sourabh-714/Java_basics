import java.util.HashMap;

public class FirstUniqueCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "hello world";
		HashMap<Character, Integer> count = new HashMap<Character, Integer>();
		int n = s.length();
		for(int i = 0; i < n; i++) {
			char c = s.charAt(i);
			count.put(c, count.getOrDefault(c, 0) + 1);
		}
		
//		System.out.println("Hashmap...");
//		for(int i : count.keySet()) {
//			
//		}
		
		for(int i = 0; i < n; i++) {
			if(count.get(s.charAt(i)) == 1) {
				System.out.println(i);
				break;
			}
		}

	}

}
