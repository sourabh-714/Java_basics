import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class ReverseWordsInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Hello World";
//		s = s.trim();
//		List<String> wordList = Arrays.asList(s.split(" "));
//		Collections.reverse(wordList);
//		s = String.join(" ", wordList);
//		System.out.println(s);
		
		Stack<String> stack = new Stack<String>();
		String words[] = s.split(" ");
		for(String word : words) {
			stack.push(word);
		}
		
		while(!stack.isEmpty()) {
			System.out.print(stack.pop() + " ");
		}
		
	}

}
