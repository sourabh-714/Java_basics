import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class StringAnagramList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String arr[] = {"cat", "act","dog","god","men"};
		int n = arr.length;
		HashMap<String, List<String>> map = new HashMap<String, List<String>>();
		for(int i = 0; i < n; i++) {
			String word = arr[i];
			char[] letters = word.toCharArray();
			Arrays.sort(letters);
			String newWord = new String(letters);
			
			if(map.containsKey(newWord)) {
				map.get(newWord).add(word);
			}
			else {
				List<String> words = new ArrayList<String>();
				words.add(word);
				map.put(newWord, words);
			}
		}
		
		for(String s : map.keySet()) {
			List<String> values = map.get(s);
			if(values.size() > 1) {
				System.out.println(values);
			}
		}

	}

}
