import java.util.Stack;

public class ValidParentheses {
	
	static boolean validParentheses(String expression) {
		int n = expression.length();
		Stack<String> stack = new Stack<String>();
		for(int i = 0; i < n; i++) {
			char singleChar = expression.charAt(i);
			if(singleChar == '(' || singleChar == '[' || singleChar == '{') {
				stack.push(String.valueOf(singleChar));
				continue;
			}
			else if(stack.isEmpty()) {
				return false;
			}
			
			switch (expression.charAt(i)){
			case ')':
				String x = stack.peek();
				stack.pop();
				if(x.equals("{") || x.equals("["))
					return false;
				break;
			case '}':
				x = stack.peek();
				stack.pop();
				if(x.equals("(") || x.equals("["))
					return false;
				break;
			case ']':
				x = stack.peek();
				stack.pop();
				if(x.equals("(") || x.equals("{"))
					return false;
				break;	
			}
		}
		return (stack.empty());
		
	}
	
	public static void main(String[] args) {
		String expression = "[]{)";
		System.out.println(validParentheses(expression));
	}
}
