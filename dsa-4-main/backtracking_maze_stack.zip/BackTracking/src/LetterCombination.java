import java.util.ArrayList;

public class LetterCombination {
	
	static String keyPadKeys[] = {"", ".+@$","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
	
	static ArrayList<String> keyPad(String number) {
		// base case, when number is end
		if(number.length() == 0) {
			ArrayList<String> str = new ArrayList<String>();
			str.add("");
			return str;
		}
		
		char firstChar = number.charAt(0);
		String remainingString = number.substring(1);
		
		// Get the first character in a string and do ascii minus and get the digit
		int index = firstChar - '0';
		String keyPadKey = keyPadKeys[index];
		
		ArrayList<String> finalResult = new ArrayList<String>();
		// Traverse the string key picking from the keyPadKeys Array
		for(int i = 0; i < keyPadKey.length(); i++) {
			ArrayList<String> temp = keyPad(remainingString);
			for(String s : temp) {
				finalResult.add(keyPadKey.charAt(i) + s);
			}
		}
		return finalResult;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(keyPad("23"));

	}

}
