public class StairClimb {
	
	static int climb(int n) {
		if(n == 1 || n == 0) {
			return 1;
		}
		else if(n == 2) {
			return 2;
		}
		else {
			return climb(n - 3) + climb(n - 2) + climb(n - 1);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(climb(4));

	}

}
