
public class IsSortedArray {
	
	static boolean isSorted(int arr[], int index) {
		if((arr.length - 1) == index) {
			return true;
		}
		if (arr[index] > arr[index+1]) {
			return false;
		}
		return isSorted(arr, index + 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {10,20,30,6,50};
		isSorted(arr, 0);
	}

}
