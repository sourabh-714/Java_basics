import java.util.ArrayList;

public class StringSubSequence {
	
//	Step 1 : Method Signature
//	static ArrayList<String> subSequence(String str) {
//		
//	}
	
//	Step 2 : get the first char and remaining string and do the recursive call
//	String str = "Ravi";
//	char currentChar = str.charAt(0);
//	String remainingStr = str.substring(1);
//	ArrayList<String> temp = subSequence(remainingStr);
	// Above one is Small Problem
	
//	Step 3 : Define the array list to store temp results and return final results
//	ArrayList<String> result = new ArrayList<String>();
//	ArrayList<String> temp = subSequence(remainingStr);
//	for(String s : temp) {
//		result.add(s);
//		result.add(currentChar + s);
//	}
	
	static ArrayList<String> subSequence(String str) {
		if(str.length() == 0) {
			ArrayList<String> emptyString = new ArrayList<String>();
			emptyString.add("");
			return emptyString;
		}
		char currentChar = str.charAt(0);
		String remainingStr = str.substring(1);
		ArrayList<String> result = new ArrayList<String>();
		ArrayList<String> temp = subSequence(remainingStr);
		for(String s : temp) {
			result.add(s);
			result.add(currentChar + s);
		}
		return result;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "Ravi";
		System.out.println(subSequence(name));

	}

}
