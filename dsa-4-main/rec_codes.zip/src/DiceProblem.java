import java.util.ArrayList;

public class DiceProblem {
	
	static ArrayList<String> reachTo10(int currentValue, int endValue) {
		if(currentValue == endValue) {
			ArrayList<String> t = new ArrayList<String>();
			t.add("");
			return t;
		}
		if(currentValue > endValue) {
			ArrayList<String> t = new ArrayList<String>();
			return t;
		}
		
		ArrayList<String> temp = new ArrayList<String>();
		for(int dice = 1; dice <= 6; dice++) {
			int newValue = currentValue + dice;
			ArrayList<String> result = reachTo10(newValue, endValue);
			for(String s : result) {
				temp.add(dice + s);
			}
		}
		return temp;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(reachTo10(0, 2));

	}

}
