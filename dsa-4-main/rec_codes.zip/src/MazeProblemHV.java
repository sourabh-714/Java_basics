import java.util.ArrayList;

public class MazeProblemHV {
	
	static ArrayList<String> getMazePath(int currentRow, int currentCol, int endRow, int endCol){
		if(currentRow == endRow && currentCol == endCol) {
			ArrayList<String> temp = new ArrayList<String>();
			temp.add("\n");
			return temp;
		}
		if(currentRow > endRow || currentCol > endCol) {
			ArrayList<String> temp = new ArrayList<String>();
			return temp;
		}
		
		ArrayList<String> results = new ArrayList<String>();
		ArrayList<String> hResults = getMazePath(currentRow, currentCol + 1, endRow, endCol);
		for(String tempResult : hResults) {
			results.add("H" + tempResult);
		}
		ArrayList<String> vResults = getMazePath(currentRow + 1, currentCol, endRow, endCol);
		for(String tempResult : vResults) {
			results.add("V" + tempResult);
		}
		
		return results;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(getMazePath(0, 0, 2, 2));

	}

}
