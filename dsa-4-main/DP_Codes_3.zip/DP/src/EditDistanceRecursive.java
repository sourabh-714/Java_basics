public class EditDistanceRecursive {
	
	static int ed(String first, String second, int m, int n) {
		if(m == 0) {
			return m;
		}
		if(n == 0) {
			return n;
		}
		if(first.charAt(m - 1) == second.charAt(n - 1)) {
			return ed(first, second, m - 1, n - 1);
		}
		int insert = ed(first, second, m, n - 1);
		int delete = ed(first, second, m - 1, n);
		int replace = ed(first, second, m - 1, n - 1);
		int min = Math.min(insert, delete);
		return 1 + Math.min(min, replace);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "sunday";
		String s2 = "saturday";
		int m = s1.length();
		int n = s2.length();
		int res = ed(s1, s2, m, n);
		System.out.println(res);
	}

}
