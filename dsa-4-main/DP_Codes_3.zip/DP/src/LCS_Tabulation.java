public class LCS_Tabulation {
	
//	TC : O(m x n), SC : (M+1)(N+1)
	static int lcs(String first, String second, int m, int n) {
		int matrix[][] = new int[m + 1][n + 1];
		
		for(int i = 0; i <= m; i++) {
			for(int j = 0; j <= n; j++) {
				if(i == 0 || j == 0) {
					matrix[i][j] = 0;
				}
				else if(first.charAt(i - 1) == second.charAt(j - 1)) {
					matrix[i][j] = matrix[i - 1][j - 1] + 1;
					System.out.println(first.charAt(i - 1) + "," + second.charAt(j - 1));
				}
				else {
					matrix[i][j] = Math.max(matrix[i - 1][j], matrix[i][j - 1]);
				}
			}
		}
		
		for(int i = 0; i <= m; i++) {
			for(int j = 0; j <= n; j++) {
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
		
		return matrix[m][n];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abcdgh";
		String s2 = "aedfhr";
		int m = s1.length();
		int n = s2.length();
		int len = lcs(s1, s2, m, n);
		System.out.println(len);
	}

}
