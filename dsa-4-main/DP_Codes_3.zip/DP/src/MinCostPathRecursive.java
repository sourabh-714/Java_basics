public class MinCostPathRecursive {
	
	static int minCostPath(int cost[][], int m, int n) {
		if (n < 0 || m < 0) {
			return Integer.MAX_VALUE;
		}
		else if(m == 0 && n == 0) {
			return cost[m][n];
		}
		else {
			return cost[m][n] + Math.min(Math.min(
					minCostPath(cost, m - 1, n  - 1),
					minCostPath(cost, m - 1, n)
					), minCostPath(cost, m, n - 1));
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int matrix[][] = {
				{2,0,6},
				{3,1,7},
				{4,5,9}
		};
		System.out.println(minCostPath(matrix, 2, 2));

	}

}
