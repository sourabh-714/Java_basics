public class KnapSackRecursive {
	
	static int knapSack(int [] weights, int values[], int max, int index) {
		if(max == 0 || index == weights.length) {
			return 0;
		}
		if(weights[index] > max) {
			return knapSack(weights, values, max, index + 1);
		}
		else {
			int option_1 = values[index] + knapSack(weights, values, max - weights[index], index + 1);
			int option_2 = knapSack(weights, values, max, index + 1);
			return Math.max(option_1, option_2);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int weights[] = {1,2,2};
		int values[] = {60,100,120};
		int maxWeight = 3;
		int result = knapSack(weights, values, maxWeight, 0);
		System.out.println(result);
	}

}
