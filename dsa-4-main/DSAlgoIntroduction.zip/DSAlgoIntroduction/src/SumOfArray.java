
public class SumOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		int arr[] = {3,2,5,6,8};
		int n = arr.length;
		int sum = 0;
		int c = 0;
		for(int i = 0; i < n; i++) {
			sum += arr[i];
			c++;
		}
	}

}
