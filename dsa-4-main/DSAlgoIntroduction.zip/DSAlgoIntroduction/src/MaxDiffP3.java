
public class MaxDiffP3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {11,4,2,5,8,1,9};
		int res = arr[1] - arr[0];
		int minVal = arr[0];
		int n = arr.length;
		for(int i = 1; i < n; i++) {
			res = Math.max(res, arr[i] - minVal);
			minVal = Math.min(minVal, arr[i]);
		}
		System.out.println(res);
	}

}
