
public class LinearSearch {
	
	static int search(int arr[], int n, int x) {
		for(int i = 0; i < n; i++) {
			if(arr[i] == x) {
				return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {4,5,3,6,8,9,12};
		int x = 9;
		int n = arr.length;
		int index = search(arr, n, x);
		System.out.println("Found at : " + index);

	}

}
