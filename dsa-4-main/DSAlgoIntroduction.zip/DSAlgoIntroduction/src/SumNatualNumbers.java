
public class SumNatualNumbers {
	
//	Approach 1 - n^2
//	static int sum(int n) {
//		int result = 0;
//		for(int i = 0; i <= n; i++) {
//			for(int j = 1; j <= i; j++) {
//				result++;
//				System.out.println(i+","+j+","+result);
//			}
//		}
//		return result;
//	}
	
//	Approach 2 - n
//	static int sum(int n) {
//		int result = 0;
//		for(int i = 0; i <= n; i++) {
//			result += i;
//		}
//		return result;
//	}
	
//	Approach 3 - constant
	static int sum(int n) {
		return n * (n + 1) / 2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int res = sum(n);
		System.out.println("Sum is : " + res);
	}

}
