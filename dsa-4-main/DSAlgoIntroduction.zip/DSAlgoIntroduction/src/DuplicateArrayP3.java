import java.util.HashMap;

public class DuplicateArrayP3 {

	public static boolean isUnique(int arr[]) {
		HashMap<Integer, Boolean> map = new HashMap<Integer, Boolean>();
		for(int i = 0; i < arr.length; i++) {
			if(map.get(arr[i]) != null) {
				return false;
			}
			map.put(arr[i], true); //{2:true, 4:true, 5:true}
		}
		return true;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {2,4,5,7,9,4};
		System.out.println(isUnique(arr) ? "Girls" : "Boys");

	}

}
