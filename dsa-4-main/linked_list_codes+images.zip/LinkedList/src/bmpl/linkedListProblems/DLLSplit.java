package bmpl.linkedListProblems;

class Node {
	int data;
	Node next;
	public Node(int data) {
		// TODO Auto-generated constructor stub
		this.data = data;
		next = null;
	}
}

public class DLLSplit {
	
	Node start;
	Node tail;
	
	void splitCircular() {
		Node fast = start;
		Node slow = start;
		if(start == null) {
			System.out.println("Empty...");
			return;
		}
		while(fast.next != start && fast.next.next != start) {
			fast = fast.next.next;
			slow = slow.next;
		}
		if(fast.next.next == start) {
			fast = fast.next;
		}
		Node start1 = start;
		Node start2 = null;
		if(start.next != start) {
			start2 = slow.next;
		}
		fast.next = slow.next;
		slow.next = start;
		print(start1);
		print(start2);
	}
	
	void print(Node start) {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
