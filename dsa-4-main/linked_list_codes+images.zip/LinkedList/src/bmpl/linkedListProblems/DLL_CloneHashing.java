package bmpl.linkedListProblems;

import java.util.HashMap;

class DLLNode {
	int data;
	DLLNode next, random;
	public DLLNode(int data) {
		// TODO Auto-generated constructor stub
		this.data = data;
		next = null;
		random = null;
	}
}

public class DLL_CloneHashing {
	
	DLLNode start;
	
	static DLLNode clone(DLLNode head) {
		HashMap<DLLNode, DLLNode> hm = new HashMap<DLLNode, DLLNode>();
		for(DLLNode current = head; current != null; current = current.next) {
			hm.put(current, new DLLNode(current.data));
		}
		
		for(DLLNode current = head; current != null; current = current.next) {
			DLLNode cloneCurrent = hm.get(current);
			cloneCurrent.next = hm.get(current.next);
			cloneCurrent.random = hm.get(current.random);
		}
		
		DLLNode head2 = hm.get(head);
		return head2;
		
	}
	
	static void print(DLLNode start) {
		DLLNode temp = start;
		while(temp != null) {
			System.out.println(temp.data + " :: " + temp.random.data );
			temp = temp.next;
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DLLNode head = new DLLNode(10);
		head.next = new DLLNode(20);
		head.next.next = new DLLNode(30);
		head.next.next.next = new DLLNode(50);
		head.next.next.next.next = new DLLNode(15);
		
		head.random =head.next.next;
		head.next.random = head.next.next.next;
		head.next.next.random = head.next;
		head.next.next.next.random = head;
		head.next.next.next.next.random = head.next.next.next;
		
		System.out.println("Original List : ");
		print(head);
		
		System.out.println("Clone List : ");
		DLLNode cloneList = clone(head);
		print(cloneList);
		
	}

}
