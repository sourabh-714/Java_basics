package bmpl.dll;

class DLLNode {
	int data;
	DLLNode next, random;
	public DLLNode(int data) {
		// TODO Auto-generated constructor stub
		this.data = data;
		next = null;
		random = null;
	}
}

public class DLL_Clone2 {
	
	static DLLNode clone(DLLNode start) {
		DLLNode next, temp;
		for(DLLNode current = start; current != null;) {
			next = current.next;
			current.next = new DLLNode(current.data);
			current.next.next = next;
			current = next;
		}
		for(DLLNode current = start; current != null; current = current.next.next) {
			current.next.random = (current.random != null) ? (current.random.next):null;
		}
		
		DLLNode original = start, copy = start.next;
		temp = copy;
		while(original != null && copy != null) {
			original.next = original.next != null ? original.next.next : original.next;
			copy.next = copy.next != null ? copy.next.next : copy.next;
			original = original.next;
			copy = copy.next;
		}
		return temp;
		
	}
	
	static void print(DLLNode start) {
		DLLNode temp = start;
		while(temp != null) {
			System.out.println(temp.data + " :: " + temp.random.data );
			temp = temp.next;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
