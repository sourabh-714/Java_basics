package stackDemo;

import java.util.Stack;

public class HistogramDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int bars[] = {2,1,6,5,2,3};
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(-1);
		int maxArea = 0;
		for(int i = 0; i < bars.length; i++) {
			while(stack.peek() != -1 && bars[stack.peek()] >= bars[i]) {
				int topElement = stack.pop();
				int rightIndex = i;
				int leftIndex = stack.peek();
				maxArea = bars[topElement] * ((rightIndex - leftIndex) - 1);
			}
			stack.push(i);
		}
		while(stack.peek() != -1) {
			maxArea = Math.max(maxArea, bars[stack.pop()] * ((bars.length - stack.peek()) - 1));
		}
		System.out.println(maxArea);
	}

}
