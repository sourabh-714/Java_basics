
public class CalculatePower {
	
	static int power(int base, int p) {
		if(p == 0) {
			return 1;
		}
		return base * power(base, p - 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int base = 2;
		int p = 5;
		System.out.println(power(base, p));
	}

}
