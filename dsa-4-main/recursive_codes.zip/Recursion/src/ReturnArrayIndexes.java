
public class ReturnArrayIndexes {
	
	static int[] searchAllIndexes(int arr[], int index, int search, int count) {
		if(index == (arr.length - 1)) {
			int myarr[] = new int[count];
			return myarr;
		}
		int arr2[] = null;
		if(arr[index] == search) {
			arr2 = searchAllIndexes(arr, index + 1, search, count + 1);
		}
		else {
			arr2 = searchAllIndexes(arr, index + 1, search, count);
		}
		if(arr[index] == search) {
			arr2[count] = index;
		}
		return arr2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {2,4,5,4,5,6,4,3};
		int count = 0;
		int index = 0;
		int elem = 4;
		int arr2[] = searchAllIndexes(arr, index, elem, count);
		for(int i : arr2) {
			System.out.print(i + ",");
		}
	}

}
