
public class TreeRecursion {
	
	static void func(int x) {
		System.out.println(x);
//		System.out.println("Hello");
		if(x >= 3) {
			return;
		}
		func(x + 1);
		func(x + 2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 0;
		func(n);
	}

}
