
public class SearchElement {
	
	static int search(int arr[], int index, int element) {
		if((arr.length) == index) {
			return -1;
		}
		if (arr[index] == element) {
			return index;
		}
		return search(arr, index + 1, element);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {10,20,30,60,6};
		System.out.println(search(arr, 0, 6));

	}

}
