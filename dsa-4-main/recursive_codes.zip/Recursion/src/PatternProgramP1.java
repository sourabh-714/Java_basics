public class PatternProgramP1 {
	
	static void printStar(int noOfStar) {
		if(noOfStar == 0) {
			return;
		}
		System.out.print("*");	// Processing Logic
		noOfStar = noOfStar - 1;	// small problem
		printStar(noOfStar);
	}
	
	static void printPattern(int rows, int currentRow) {
		if(rows == 0) {
			return;
		}
		printStar(currentRow);		// Print row
		System.out.println();		// Move to new line
		printPattern(rows - 1, currentRow + 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printPattern(5, 1);

	}

}
