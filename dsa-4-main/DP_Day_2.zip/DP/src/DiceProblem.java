public class DiceProblem {
	
//	Without DP
	static int countWays(int currentValue, int endValue) {
		if(currentValue == endValue) {
			return 1;
		}
		if(currentValue > endValue) {
			return 0;
		}
		int count = 0;
		for(int dice = 1; dice <= 6; dice++) {
			count = count + countWays(currentValue + dice, endValue);
		}
		return count;
	}
	
//	With DP : Top Down : Memoization
	static int countWaysWithDP(int currentValue, int endValue, int [] cache) {
		if(currentValue == endValue) {
			return 1;
		}
		if(currentValue > endValue) {
			return 0;
		}
		
		if(cache[currentValue] != 0) {
			return cache[currentValue];
		}
		
		int count = 0;
		for(int dice = 1; dice <= 6; dice++) {
			count = count + countWaysWithDP(currentValue + dice, endValue, cache);
		}
		cache[currentValue] = count;
		return count;
	}
	
//	With DP : Tabulation
	static int tabulation(int start, int endValue) {
		int cache[] = new int[endValue + 1];
		cache[endValue] = 1;
		for(int i = endValue - 1; i >= 0; i--) {
			int count = 0;
			for(int dice = 1; dice <= 6 && dice + i < cache.length; dice++) {
				count = count + cache[dice + i];
			}
			cache[i] = count;
		}
		return cache[start];
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 30;
		int result = 0;
		System.out.println("Without DP...");
		long startTime = System.currentTimeMillis();
//		int result = countWays(0, 30);
		long endTime = System.currentTimeMillis();
//		System.out.println(result);
//		System.out.println("Total time taken : " + (endTime - startTime));
		
//		System.out.println("With DP Memoization...");
//		startTime = System.currentTimeMillis();
//		result = countWaysWithDP(0, 30, new int[n + 1]);
//		endTime = System.currentTimeMillis();
//		System.out.println(result);
//		System.out.println("Total time taken : " + (endTime - startTime));
		
		System.out.println("With DP Tabulation...");
		startTime = System.currentTimeMillis();
		result = tabulation(0, 30);
		endTime = System.currentTimeMillis();
		System.out.println(result);
		System.out.println("Total time taken : " + (endTime - startTime));

	}

}
