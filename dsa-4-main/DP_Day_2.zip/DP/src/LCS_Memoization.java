public class LCS_Memoization {
	
	static int lcs_memo(String X, String Y, int m, int n, int dp[][]) {
		if(m == 0 || n == 0) {
			return 0;
		}
		
		if(dp[m - 1][n - 1] != 0) {
			return dp[m - 1][n - 1];
		}
		
		if(X.charAt(m - 1) == Y.charAt(n - 1)) {
			dp[m - 1][n - 1] = 1 + lcs_memo(X, Y, m - 1, n - 1, dp);
		}
		
		else {
			dp[m - 1][n - 1] = Math.max(
					lcs_memo(X, Y, m, n - 1, dp),
					lcs_memo(X, Y, m - 1, n, dp));
		}
		
		return dp[m - 1][n - 1];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abcdgh";
		String s2 = "aedfhr";
		int cache[][] = new int[s1.length()][s2.length()];
		int len = lcs_memo(s1, s2, s1.length(), s2.length(), cache);
		System.out.println(len);

	}

}
