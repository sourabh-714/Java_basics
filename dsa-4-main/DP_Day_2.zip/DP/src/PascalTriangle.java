import java.util.ArrayList;
import java.util.List;

public class PascalTriangle {
	
	public static List<List<Integer>> generate(int numRows) {
		List<List<Integer>> triangle = new ArrayList<List<Integer>>();
		triangle.add(new ArrayList<Integer>());
		triangle.get(0).add(1);
		
		for(int rowNum = 1; rowNum < numRows; rowNum++) {
			List<Integer> row = new ArrayList<Integer>();
			List<Integer> prevRow = triangle.get(rowNum - 1);	// Previous Row
			
//			1st element of row
			row.add(1);
			
			for(int j = 1; j < rowNum; j++) {
				row.add(prevRow.get(j - 1) + prevRow.get(j));
			}
			
//			Last element of row
			row.add(1);
			triangle.add(row);
		}
		return triangle;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<List<Integer>> tri = generate(5);
		System.out.println(tri);
	}

}
