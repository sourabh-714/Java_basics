package oops.share2;
//as the PErson class is in other package hence we have to provide our current class with this Person using import keyword
import oops.share.Person;

class Employee extends Person{
    int id=9000;
    protected int salary=900;
    void print(){
        //protected property= it is converted to private
        System.out.println("name is "+this.name);
        //default is not inherited
        // System.out.println("weight is "+this.weight);
    }
}

public class Test {
    public static void main(String[] args) {
        Employee e=new Employee();
        System.out.println("height: "+e.height);
        System.out.println("id : "+e.id);
        System.out.println("salary is "+e.salary);
        // System.out.println("weight is : "+e.weight);
        // System.out.println("name  is: "+e.name);

    }
}
