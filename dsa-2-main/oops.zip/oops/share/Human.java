package oops.share;

//visibility is public 
// public class Human {

//     public int height=90;
//     private int weight=78;
//     String name="tina";
//     protected String phone="3446575";
    
//     // public static void main(String[] args) {
//     //    System.out.println((new Human()).weight); 
//     // }
// }

//visibility =>deafult
class Human {

    public int height=90;
    private int weight=78;
    String name="tina";
    protected String phone="3446575";
  
}

