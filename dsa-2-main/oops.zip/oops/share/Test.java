package oops.share;
//Employee and Human class are in the same package
// within the package all the classes are visible to each other

class Employee extends Human{
    int salary=9000;
}

public class Test {
public static void main(String[] args) {
    Employee e=new Employee();
    // System.out.println("this is employee salary "+e.salary);
    // System.out.println("this is height of employee "+e.height);

    // System.out.println("name is :"+e.name);
    // System.out.println("phone is "+e.phone);
    // System.out.println("this is weight of employee "+e.weight);


    //human =>public same package
    // System.out.println("this is employee salary "+e.salary);
    // System.out.println("this is height of employee "+e.height);
    // System.out.println("name is :"+e.name);
    // System.out.println("phone is "+e.phone);
    // System.out.println("this is weight of employee "+e.weight);
}    
}
