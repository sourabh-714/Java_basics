package oops.share;

public class Person {
    public int height=90;
    int weight=89;
    protected String name="tia";
    

}

//default visiblity =>inh not possible in different package
//  class Person {
//         public int height=90;
//         int weight=89;
//         protected String name="tia";
    
//     }