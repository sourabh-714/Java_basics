package oops.encapsulation;
//Encapsulation =>data members and member function =>bind together
class Person{//class is an example of encapsulation

    //all the attributes of the class are private and functions are public
    private int height;
    private int weight;
    private String address;
    private String phone;
    private String name;
//constructors have name same as class name
//constructor Overloading 
//constuctor does not return anything
//Signature of a function  => using name of the function +argument(data type) 
//read(int firstNumber , int secondNumber){}=>read(int ,int)
//read(int sum , int diff){}=>read(int ,int)
//read(int sum , float diff){}=>read(int ,float)
//read(90,89);
    Person(){
        System.out.println("Iam a default Constructor");
        this.height=20;
    }

    Person(int height , int weight){
        System.out.println("Iam a Parameterized Constructor  with height and weight");
        this.height=height;
        this.weight=weight;
    }
    Person(String name){
        this();
        System.out.println("this is a param constructor=> name");
        this.name=name;
    }
    // Person(int height, int weight , String name){
    //     System.out.println("Iam a Parameterized Constructor  with height and weight and name");
    //     this.height=height;
    //     this.weight=weight;
    //     this.name=name;
    // }
    Person(int height, int weight, String name, String phone , String address){
        System.out.println("Iam a Parameterized Constructor  with height and weight name address and phone");
        this.height=height;
        this.weight=weight;
        this.phone=phone;
        this.name=name;
        this.address=address;
    }

    //setters

    public void setHeight(int height){
        this.height=height;
    }
    public void setWeight(int weight){
        this.weight=weight;
    }
    public void setAddress(String address){
        this.address=address;
    }
    public void setPhone(String phone){
        this.phone=phone;
    }
    public void setName(String name){
        this.name=name;
    }
//getters
    public int getHeight(){
        return this.height;
    }
    public int getWeight(){
        return this.weight;
    }
    public String getPhone(){
        return this.phone;
    }
    public String getAddress(){
        return this.address;
    }
    public String getName(){
        return this.name;
    }
//function overloading=>type of different , number of argument, 
//argument in different order
//read(float,int){}   read(int, float){}
    public void printInfo(int choice){
        if(choice==1){
            System.out.println("the name is : "+this.name);
        }
        else if(choice ==2){
            System.out.println("the phone is : "+this.phone);
        }
        else{
            System.out.println("No info to publish");
        }

    }
    public void printInfo(){
            System.out.println("name is : "+this.name);
            System.out.println("height is : "+this.height);
            System.out.println("weight is : "+this.weight);
            System.out.println("phone is : "+this.phone);
            System.out.println("Address is : "+this.address);
    }
    public void printInfo(char choice){
        if(choice=='a'){
            System.out.println("the Address is : "+this.address);
        }
        else if(choice =='b'){
            System.out.println("the phone is : "+this.phone);
        }
        else{
            System.out.println("No info to publish");
        }
    }
    public void printInfo(int choice , int choice2){
    }
}


public class Test {
 
public static void main(String[] args) {
    //constructors are special type of functions 
    //they are called only once during the creation of an object
    //initialization purpose
    // Person p1=new Person();//default constructors=>by default available with every class 
    // Person p2=new Person(156,56);
    // Person p3=new Person(167,89,"tina");
    Person p4=new Person(167,45,"tina","345665-4554","t- block");
    p4.printInfo();
    System.out.println("================================");
    p4.printInfo(1);
    System.out.println("================================");
    p4.printInfo('a');
    //constuctor chaining 
        //Person p5=new Person("tia");
       // System.out.println(p5.getHeight()+ "    "+p5.getName());
      
    //p.name="ram";
    // p.setName("ram");
    // p.setPhone("67890-34234");
    // System.out.println(p.getName());
}
 

}
