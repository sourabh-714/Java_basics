package oops;
//overriding=>runtime polymorphism 
//polymorphism=>means a thing which can take many forms is said to showing =>polyformism
class Animal{
    int speed;
    boolean eyes;
    boolean hair;
    int leg;
    //many more properties
    void eat(){
        System.out.println("i eat grass");
    }
}
class Human extends Animal{
//we do eat but not in way defined by Animal 
//either we could have changed the name 
//eat()=> still there
//wrong definition
//hence overriding
    // void eat2(){
    //     System.out.println("human eat grains and fish and milk");
    // }
      void eat(){
        System.out.println("human eat grains and fish and milk");
    }
}
class Cat extends Animal {
    void eat(){
        System.out.println("i drink milk");
    }
}


public class Test2 {
    public static void main(String[] args) {
        
        Cat c=new Cat();
       // c.eat();
        Human h=new Human();
        //h.eat();
        Animal a=new Animal();
        //a.eat();
        //runtime polymorphism
        Animal obj=c;
        obj.eat();//cat functiom

        obj=h;
        obj.eat();

        obj=a;
        obj.eat();
        

    }
}
