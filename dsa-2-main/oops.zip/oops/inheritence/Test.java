package oops.inheritence;
//time 
//we can only extend one class at a time 
class Car2{
    private    int height=90;
    Car2(){

    }
    Car2(int height){
        this.height=height;
    }
}
class Car extends Car2{
    int speed=90;
    int tankCapacity=34;
    int width=78;
    int color=4;
    int length=13;
    String model="abcd";

    Car(){

    }
    Car(int speed , int tankCapacity, int width, int color , int length , String model,int height){
       super(height);
        this.speed=speed;
        this.tankCapacity=tankCapacity;
        this.color=color;
        this.length=length;
        this.width=width;
        this.model=model;
    }

}

class TataCar extends Car{

    boolean airBags=true;
    boolean dashboard=true;
    boolean mirror=true;

    TataCar(){

    }
    TataCar(boolean airBags, boolean dashboard, boolean mirror){
        this.airBags =airBags;
        this.dashboard=dashboard;
        this.mirror=mirror;

    }
    TataCar(boolean airBags, boolean dashboard){

    }
    TataCar(boolean airBags, boolean dashboard, boolean mirror,int speed , int tankCapacity, int width, int color , int length , String model,int height){
        super(speed ,tankCapacity, width,color ,length ,model,height);
       // this(airBags,dashboard,mirror);
        this.airBags =airBags;
        this.dashboard=dashboard;
        this.mirror=mirror;
        
        // this.speed=speed;
        // this.tankCapacity=tankCapacity;
        // this.color=color;
        // this.length=length;
        // this.width=width;
        // this.model=model;
    }
}



public class Test {
public static void main(String[] args) {
    TataCar newCar=new TataCar(false,false,false,10,10,10,10,10,"abcd",900); 
    System.out.println(newCar.airBags+" "+newCar.dashboard+" "+newCar.length+" "+newCar.model+" "+newCar.height);   
}    
}
